const burger_menu = document.querySelector('.burger_menu');
const nav_ul = document.querySelector('.nav_ul');
const close_menu = document.querySelector('.close_menu');
const mode = document.querySelector('.dark_mode');
const dark_light = document.querySelector('.dark_light');
const light_mode = document.querySelector('.light_mode');
const video = document.querySelector('.video');
const video2 = document.querySelector('.video2');
const video3 = document.querySelector('.video3');
const video4 = document.querySelector('.video4');
video.addEventListener('click', () => {
    if (video.paused === false) {
        video.pause()
    } else {
        video.play()
    }
    video2.pause()
    video4.pause()
    video3.pause()
})

video2.addEventListener('click', () => {
    if (video2.paused === false) {
        video2.pause()
    } else {
        video2.play()
    }
    video3.pause()
    video4.pause()
    video.pause()
})


video3.addEventListener('click', () => {
    if (video3.paused === false) {
        video3.pause()
    } else {
        video3.play()
    }
    video2.pause()
    video4.pause()
    video.pause()

})

video4.addEventListener('click', () => {
    if (video4.paused === false) {
        video4.pause()
    } else {
        video4.play()
    }
    video3.pause()
    video2.pause()
    video.pause()
})

// => mrnu bar event

burger_menu.addEventListener('click', () => {
    nav_ul.classList.add('show');
    document.body.classList.add('hidden')
})
close_menu.addEventListener('click', () => {
    nav_ul.classList.remove('show')
    document.body.classList.remove('hidden')
})


// => dark mode event

dark_light.addEventListener('click', () => {
    document.body.classList.toggle('change_color');
    light_mode.classList.toggle('none')
})

// const options = {
//     time: '0.5s', // default: '0.3s'
//     mixColor: '#fff', // default: '#fff'
//     backgroundColor: '#fff', // default: '#fff'
//     buttonColorDark: '#100f2c', // default: '#100f2c'
//     buttonColorLight: '#fff', // default: '#fff'
//     saveInCookies: false, // default: true,
//     label: '🌓', // default: ''
//     autoMatchOsTheme: true // default: true
// }

// const darkmode = new Darkmode(options);
// darkmode.showWidget();

const swiper = new Swiper('.swiper', {
    // Optional parameters
    slidesPerColumn: 2,
    slidesPerView: 4,
    keyboardControl: true,
    spaceBetween: 10,


    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        // when window width is <= 499px
        350: {
            slidesPerView: 1.5,
            spaceBetweenSlides: 0
        },
        // when window width is <= 999px
        440: {
            slidesPerView: 2.4,
            spaceBetweenSlides: 10
        },
        650: {
            slidesPerView: 4,
            spaceBetweenSlides: 10
        },
        870: {
            slidesPerView: 4,
            spaceBetweenSlides: 10
        }
    },


    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
});

const swipers = new Swiper('.swiper', {
    slidesPerView: 4,
    keyboardControl: true,
    spaceBetween: 10,

    breakpoints: {
        // when window width is <= 499px
        250: {
            slidesPerView: 1,
            spaceBetweenSlides: 0
        },
        // when window width is <= 999px
        440: {
            slidesPerView: 2,
            spaceBetweenSlides: 10
        },
        650: {
            slidesPerView: 3,
            spaceBetweenSlides: 10
        },
        967: {
            slidesPerView: 2,
            spaceBetweenSlides: 10
        }
    },



    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

    // And if we need scrollbar
    scrollbar: {
        el: '.swiper-scrollbar',
    },
});